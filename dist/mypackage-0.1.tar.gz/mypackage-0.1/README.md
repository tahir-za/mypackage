# mypackage

mypackage is was created to learn how to publish my own python packages.


##building this package locally
'python setup.py sdist'

## Installation
'pip install git+https://github.com/tahir-za/mypackage.git'

##Updating
'pip install --upgrade git+'https://github.com/tahir-za/mypackage.git'

## License
[MIT](https://choosealicense.com/licenses/mit/)
